# SDM Extension — Edge

نسخه Microsoft Edge اکستنشن Surena Download Manager — کد همان نسخه Chrome است
(Edge موتور Chromium دارد) با شناسه مرورگر `edge`.

## نصب (Load unpacked)

1. در Edge برو به: `edge://extensions`
2. از منوی کناری **Developer mode** را روشن کن.
3. **Load unpacked** را بزن و همین پوشه (`SDM_Extension_Edge`) را انتخاب کن.

## تنظیمات مرتبط در اپ

Settings → Integration → چیپ **Edge** باید فعال باشد تا لینک‌های Edge صفحه
دانلود را باز کنند؛ در غیر این صورت لینک بی‌صدا رد می‌شود.

> برای اعمال تغییر چیپ‌ها، بعد از تیک‌زدن دکمه **Save Changes** تنظیمات را بزن.
