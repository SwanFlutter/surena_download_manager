// SDM – Surena Download Manager (WebExtension — Chrome / Edge / Firefox)
const APP_URL = 'http://127.0.0.1:9614';

// Host browser identity — differs per extension folder (chrome/edge/firefox);
// the app applies the Settings → Integration browser-selection gate with it.
const BROWSER_ID = 'firefox';

// Firefox exposes promise-based `browser.*`; Chrome/Edge (MV3) have
// promise-based `chrome.*`. downloads.onDeterminingFilename is Chromium-only.
const api = typeof browser !== 'undefined' ? browser : chrome;
const HAS_DETERMINING = !!(api.downloads && api.downloads.onDeterminingFilename);

// ---------- Helpers ----------
async function isAppRunning() {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 800);
    const res = await fetch(`${APP_URL}/ping`, { signal: ctrl.signal });
    clearTimeout(timer);
    return res.ok;
  } catch {
    return false;
  }
}

async function getCookies(url) {
  try {
    const list = await api.cookies.getAll({ url });
    return list.map(c => `${c.name}=${c.value}`).join('; ');
  } catch {
    return '';
  }
}

function fileNameFromPath(path) {
  if (!path) return '';
  return path.split(/[\\/]/).pop();
}

async function sendToApp(info) {
  const body = {
    url: info.url,
    filename: info.filename || '',
    fileSize: info.fileSize ?? -1,
    mime: info.mime || '',
    referrer: info.referrer || '',
    cookies: await getCookies(info.url),
    userAgent: navigator.userAgent,
    browser: BROWSER_ID,
  };
  const res = await fetch(`${APP_URL}/download`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return res.ok;
}

function notify(message) {
  api.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: 'Surena Download Manager',
    message,
  });
}

// ---------- Capture browser downloads ----------
// Primary hook (Chromium only): downloads.onDeterminingFilename fires BEFORE
// the "Save As" dialog opens and before anything is written to disk. Canceling
// while filename determination is still pending aborts the target determiner,
// so no local dialog, no download bubble, no file.
// It accepts a single listener browser-wide; handledIds prevents double-sends
// between this path and the onCreated fallback (Firefox never receives the
// determining event, so onCreated is its only hook).
const handledIds = new Set();
function claimDownload(id) {
  if (handledIds.size > 1000) handledIds.clear();
  handledIds.add(id);
}

if (HAS_DETERMINING) {
  api.downloads.onDeterminingFilename.addListener((item, suggest) => {
    determineIntercept(item, suggest);
    return true; // async — suggest() is always called in determineIntercept
  });
}

async function determineIntercept(item, suggest) {
  // Unblock the filename determiner with Chrome's default name — used both
  // when Chrome must continue normally and after we already canceled.
  const keepDefault = () => {
    try {
      suggest({ filename: item.filename || fileNameFromPath(item.url) });
    } catch {}
  };

  const { enabled } = await api.storage.local.get({ enabled: true });
  const url = item.finalUrl || item.url;
  if (
    !enabled ||
    !/^https?:\/\//i.test(url) || // skip blob:, data:, file:
    (item.state && item.state !== 'in_progress')
  ) {
    keepDefault();
    return;
  }
  claimDownload(item.id);

  // App is not running -> let Chrome continue normally
  if (!(await isAppRunning())) {
    keepDefault();
    return;
  }

  // Hand off to SDM: kill Chrome's download FIRST — while filename
  // determination is still waiting for suggest() — so the Save As dialog
  // never opens; then unblock the determiner and send the link to the app.
  try { await api.downloads.cancel(item.id); } catch {}
  try { await api.downloads.erase({ id: item.id }); } catch {}
  keepDefault();
  try {
    await sendToApp({
      url,
      filename: fileNameFromPath(item.filename) || fileNameFromPath(url),
      fileSize: item.totalBytes,
      mime: item.mime,
      referrer: item.referrer,
    });
  } catch {}
}

api.downloads.onCreated.addListener((item) => {
  // On Chromium give the primary hook a beat to claim the download; on
  // Firefox there is no primary hook, so act immediately.
  if (HAS_DETERMINING) {
    setTimeout(() => intercept(item), 100);
  } else {
    intercept(item);
  }
});

async function intercept(item) {
  if (handledIds.has(item.id)) return;
  const { enabled } = await api.storage.local.get({ enabled: true });

  const url = item.finalUrl || item.url;
  if (!enabled) return;
  if (!/^https?:\/\//i.test(url)) return; // skip blob:, data:, file:
  if (item.state && item.state !== 'in_progress') return;
  claimDownload(item.id);

  // Pause Chrome's download first so no bytes land locally while we check.
  try { await api.downloads.pause(item.id); } catch {}

  // App is not running -> let Chrome continue normally
  if (!(await isAppRunning())) {
    api.downloads.resume(item.id).catch(() => {});
    return;
  }

  try {
    const ok = await sendToApp({
      url,
      filename: fileNameFromPath(item.filename) || fileNameFromPath(url),
      fileSize: item.totalBytes,
      mime: item.mime,
      referrer: item.referrer,
    });

    if (ok) {
      try { await api.downloads.cancel(item.id); } catch {}
      try { await api.downloads.erase({ id: item.id }); } catch {}
    } else {
      api.downloads.resume(item.id).catch(() => {});
    }
  } catch {
    api.downloads.resume(item.id).catch(() => {});
  }
}

// ---------- Context menu ----------
api.runtime.onInstalled.addListener(() => {
  api.contextMenus.create({
    id: 'sdm-download',
    title: 'Download with SDM',
    contexts: ['link', 'video', 'audio', 'image'],
  });
});

api.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'sdm-download') return;
  const url = info.linkUrl || info.srcUrl;
  if (!url) return;

  if (!(await isAppRunning())) {
     notify('Surena Download Manager is not running. Please start the app first.');
    return;
  }
  try {
    await sendToApp({ url, referrer: tab?.url });
  } catch {
    notify('Failed to send the link to SDM.');
  }
});

// ---------- Popup messages ----------
api.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'status') {
    isAppRunning().then(running => sendResponse({ running }));
    return true; // async response
  }
});
