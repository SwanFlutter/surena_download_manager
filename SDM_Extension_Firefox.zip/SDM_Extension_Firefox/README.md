# SDM Extension — Firefox

نسخه Firefox اکستنشن Surena Download Manager — عملکرد مشابه نسخه Chrome:
شکار خودکار دانلودهای مرورگر و ارسال به اپ دسکتاپی روی `127.0.0.1:9614`.

## نصب (موقت — Developer)

1. در Firefox برو به: `about:debugging#/runtime/this-firefox`
2. **Load Temporary Add-on…** را بزن و فایل `manifest.json` همین پوشه را انتخاب کن.

> نسخه موقتی با ری‌استارت Firefox حذف می‌شود. برای نصب دائمی باید پکیج با
> `web-ext sign` (یا انتشار در addons.mozilla.org) امضا شود — `browser_specific_settings.gecko.id`
> در manifest از قبل تنظیم شده است.

## نکته فنی

- Firefox ایونت `downloads.onDeterminingFilename` را (برخلاف Chromium) ندارد؛
  در این نسخه شکار از طریق `downloads.onCreated` انجام می‌شود: دانلود pause می‌شود،
  به اپ فرستاده می‌شود و سپس cancel/erase — اگر اپ بسته باشد، دانلود به‌صورت
  عادی Firefox ادامه پیدا می‌کند.
- در `about:addons` → این افزونه → تب Permissions، دسترسی‌های Host را روی
  «Allow» بگذار تا کوکی/رفرر سایت‌ها هم به اپ برسد.

## تنظیمات مرتبط در اپ

Settings → Integration → چیپ **Firefox** باید فعال باشد تا لینک‌های Firefox
صفحه دانلود را باز کنند؛ در غیر این صورت لینک بی‌صدا رد می‌شود.
