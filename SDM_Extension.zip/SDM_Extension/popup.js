// SDM – Surena Download Manager – Popup script

const enabledCheckbox  = document.getElementById('enabled');
const dotEl            = document.getElementById('dot');
const statusTextEl     = document.getElementById('status-text');

// ── Load saved settings ───────────────────────────────────────────────────
chrome.storage.local.get({ enabled: true }, (settings) => {
  enabledCheckbox.checked = settings.enabled;
});

// ── Persist on change ─────────────────────────────────────────────────────
enabledCheckbox.addEventListener('change', () => {
  chrome.storage.local.set({ enabled: enabledCheckbox.checked });
});

// ── Toggle rows also respond to clicking the label text ───────────────────
document.getElementById('capture-row').addEventListener('click', (e) => {
  if (e.target.tagName === 'INPUT') return; // handled natively
  enabledCheckbox.checked = !enabledCheckbox.checked;
  chrome.storage.local.set({ enabled: enabledCheckbox.checked });
});

// ── App connection status ─────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: 'status' }, (res) => {
  const running = !!(res && res.running);

  statusTextEl.textContent = running ? 'Connected' : 'Not running';
  statusTextEl.classList.toggle('connected', running);
  dotEl.classList.toggle('connected', running);
});

// ── More Settings → open SDM app settings page ───────────────────────────
document.getElementById('more-settings').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: 'http://127.0.0.1:9614/settings' });
});
